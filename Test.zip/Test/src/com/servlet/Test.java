package com.servlet;
import java.util.*;

import org.apache.catalina.User;
import org.hibernate.*;

import com.BDD.*;

public class Test {
	 public static void main(String[] args)
		        throws HibernateException {
		 Session session = HibernateUtil.currentSession();
		Chat contact = (Chat) session.load("/WEB-INF/Chat.class", new Integer(1));
		 Query query = session.createQuery("from Chat" );
		 List list = query.list();
		 //List list = session.find("from user" );
		 Iterator it = list.iterator();
		 while (it.hasNext()) {
			 Chat chat = (Chat)it.next();
			   System.out.println(contact.getNomJaponais());
		 }

		 HibernateUtil.closeSession();
}
}
