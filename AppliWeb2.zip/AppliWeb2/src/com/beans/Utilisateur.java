/**
 * 
 */
package com.beans;

/**
 * @author laureduchemin
 *
 */
public class Utilisateur {
	
	private String pseudo;
	private String email;
    private String motDePasse;
    

    public void setPseudo(String pseudo) {
    this.pseudo = pseudo;
    }
    
    public String getPseudo() {
    return pseudo;
    }
       
    public void setEmail(String email) {
    this.email = email;
    }
    public String getEmail() {
    return email;
    }

    public void setMotDePasse(String motDePasse) {
    this.motDePasse = motDePasse;
    }
    public String getMotDePasse() {
    return motDePasse;
    }
}
