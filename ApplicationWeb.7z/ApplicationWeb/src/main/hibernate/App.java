package hibernate;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

/**
 * Hello world!
 *
 */
public class App 
{
    @SuppressWarnings("unchecked")
	public static void main( String[] args )
    {
    				Session session = HibernateUtil.getSessionFactory().openSession();
    		        session.beginTransaction();
    		        Chat chat = new Chat();
    		        System.out.println(chat.getNomAnglais());
    		        session.getTransaction().commit();
    		        Query query = session.createQuery("from Chat");
    		        List<Chat> listeChat = query.list();
    		        for(Iterator<Chat> it = listeChat.iterator(); it.hasNext(); ){
    		        	Chat chatProv = it.next();
    		        	System.out.println(chatProv.getNomAnglais());
    				}		        
    }
}
