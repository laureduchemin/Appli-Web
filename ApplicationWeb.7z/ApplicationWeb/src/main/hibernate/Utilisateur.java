package hibernate;

import java.io.Serializable;

public class Utilisateur implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String pseudo;
	private String mdp;
	private boolean administrateur;
	private String email;
	private boolean banni;
	
	public String getPseudo(){
		return pseudo;
	}
	public void setPseudo(String pseudo){
		this.pseudo = pseudo;
	}
	
	public String getMdp(){
		return mdp;
	}
	public void setMdp(String mdp){
		this.mdp = mdp;
	}
	
	public boolean getAdministrateur(){
		return administrateur;
	}
public void setAdministrateur(boolean administrateur){
		this.administrateur = administrateur;
	}
	
	public String getEmail(){
		return email;
	}
	public void setEmail(String email){
		this.email = email;
	}
	
	public boolean getBanni(){
		return banni;
	}
	public void setBanni(boolean banni){
		this.banni = banni;
	}
}
