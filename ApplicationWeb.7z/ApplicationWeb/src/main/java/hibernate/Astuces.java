package hibernate;

import java.io.Serializable;

public class Astuces implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nomChat;
	private String pseudoJoueur;
	private String astuce;
	
	public String getNomChat(){
		return nomChat;
	}
	public void setNomChat(String nomChat){
		this.nomChat = nomChat;
	}
	
	public String getPseudoJoueur(){
		return pseudoJoueur;
	}
	public void setPseudoJoueur(String pseudoJoueur){
		this.pseudoJoueur = pseudoJoueur;
	}
	
	public String getAstuce(){
		return astuce;
	}
	public void setAstuce(String astuce){
		this.astuce = astuce;
	}
	
}
