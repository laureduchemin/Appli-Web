package hibernate;

import java.io.Serializable;

public class Vote implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String pseudo;
	private String astuce;
	
	public String getPseudo(){
		return pseudo;
	}
	public void setPseudo(String pseudo){
		this.pseudo = pseudo;
	}
	
	public String getAstuce(){
		return astuce;
	}
	public void setAstuce(String astuce){
		this.astuce = astuce;
	}
	
}
